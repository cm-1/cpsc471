First, create a MySQL database schema called "clinicdb", and then import the file "clinicdb.sql" to populate it.

To let the app connect to the database, you'll have to edit "db.js" to use the correct username and password for your database.

Navigate to the directory containing "app.js" and run the command "node app.js".

Visit http://localhost:3000 and create an account or log in. The following accounts already exist.
For ease of memorization, the default accounts' passwords are just their usernames again.
These can be changed, if you'd like, once you've logged in.
	
That's all the technicall stuff! For the rest, consult the user manual in the pdf.
